/**
 * TANTRAMOUR 2027 — Référentiel : Ateliers Proposés
 * Fichier géré via Rapport_Ateliers_Proposes.html
 */
var ATELIERS = [
  {id:"A_1337",nomFr:"Artistique 1",nomEn:"",animateurs:["R_LINDA"],type:"ATELIER ARTISTIQUE",dureeH:1,dureeMin:30,prepDuration:20,rangeDuration:15,descFr:"Description en Francais",descEn:"English description",statut:"APPROVED",createdAt:"2026-09-22T08:08:26.268Z",updatedAt:"2026-09-28T20:05:56.978Z"},
  {id:"A_5826",nomFr:"TEST atelier 1",nomEn:"",animateurs:["R_MATTHIEU"],type:"ATELIERS TANTRA",dureeH:2,dureeMin:0,prepDuration:0,rangeDuration:0,descFr:"",descEn:"",statut:"REJECTED",createdAt:"2026-09-22T08:38:13.509Z",updatedAt:"2026-09-23T08:25:45.948Z"},
  {id:"A_3974",nomFr:"TANTRA 1",nomEn:"",animateurs:["R_AUDREY"],type:"ATELIERS TANTRA",dureeH:1,dureeMin:0,prepDuration:0,rangeDuration:0,descFr:"",descEn:"",statut:"APPROVED",createdAt:"2026-09-22T09:18:43.486Z",updatedAt:"2026-09-23T08:21:56.407Z"},
  {id:"A_5692",nomFr:"Tantra Café",nomEn:"",animateurs:["R_SANDRINE"],type:"TANTRA CAFE",dureeH:2,dureeMin:0,prepDuration:0,rangeDuration:0,descFr:"",descEn:"",statut:"APPROVED",createdAt:"2026-09-22T10:01:27.960Z",updatedAt:"2026-09-23T08:26:06.462Z"},
  {id:"A_4797",nomFr:"Love Temple 1",nomEn:"dgsdg",animateurs:["R_CLEMENT"],type:"LOVE TEMPLE",dureeH:3,dureeMin:0,prepDuration:0,rangeDuration:0,descFr:"dsgsdg",descEn:"sgdsgds",statut:"APPROVED",createdAt:"2026-09-22T10:12:35.270Z",updatedAt:"2026-09-23T08:26:43.343Z"},
  {id:"A_1936",nomFr:"Dj Set",nomEn:"",animateurs:["R_SURPRISE"],type:"DJ Set",dureeH:2,dureeMin:0,prepDuration:0,rangeDuration:0,descFr:"dgds",descEn:"",statut:"APPROVED",createdAt:"2026-09-22T10:44:28.757Z",updatedAt:"2026-09-23T08:26:12.400Z"},
  {id:"A_5094",nomFr:"Conférence 1",nomEn:"dsfdsf",animateurs:["R_LAURENT","R_LAURENCE"],type:"CONFERENCE",dureeH:1,dureeMin:30,prepDuration:0,rangeDuration:0,descFr:"sdfds",descEn:"sfd",statut:"APPROVED",createdAt:"2026-09-22T12:04:22.194Z",updatedAt:"2026-09-23T08:26:22.223Z"},
  {id:"A_8383",nomFr:"Meditation du matin",nomEn:"",animateurs:["R_SEVDA"],type:"MEDITATION / YOGA",dureeH:1,dureeMin:30,prepDuration:0,rangeDuration:0,descFr:"",descEn:"",statut:"APPROVED",createdAt:"2026-09-22T12:46:49.349Z",updatedAt:"2026-09-23T08:23:11.061Z"},
  {id:"A_3781",nomFr:"Céremonie 1",nomEn:"",animateurs:["R_AMANA"],type:"CEREMONIE & CONCERT",dureeH:2,dureeMin:30,prepDuration:0,rangeDuration:0,descFr:"",descEn:"",statut:"APPROVED",createdAt:"2026-09-22T12:53:57.941Z",updatedAt:"2026-09-23T08:24:09.071Z"}
];
