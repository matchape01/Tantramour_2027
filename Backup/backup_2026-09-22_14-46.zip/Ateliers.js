/**
 * TANTRAMOUR 2027 — Référentiel : Ateliers Proposés
 * Fichier géré via Rapport_Ateliers_Proposes.html
 */
var ATELIERS = [
];
